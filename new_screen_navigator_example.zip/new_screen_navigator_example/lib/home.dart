import 'package:flutter/material.dart';
import 'newscreen.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => new _HomeState();
}

class _HomeState extends State<Home> {
  TextEditingController _nameFieldController = new TextEditingController();
  String _result = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Navigator Example'),
        ),
        body: Container(
          padding: EdgeInsets.all(20.0),
          child: Column(
            children: <Widget>[
              TextField(
                controller: _nameFieldController,
              ),
              Padding(
                padding: EdgeInsets.all(20.0),
                child: RaisedButton(
                  child: Text('Launch Screen'),
                  onPressed: () {
                    _navigateToNewScreen(context);
                  },
                ),
              ),
              Padding(
                padding: EdgeInsets.all(15.0),
                child: Text(
                  '$_result',
                  style: TextStyle(
                    color: Colors.blue,
                    fontSize: 22.0,
                  ),
                ),
              ),
            ],
          ),
        ));
  }

  _navigateToNewScreen(BuildContext context) async {
    Map results = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => NewScreen(name: _nameFieldController.text)),
    );

    if (results.containsKey('greeting')) {
      _result = results['greeting'];
    }
  }
}
